/*
 * TCSS 305 - Road Rage
 */
package model;
import java.util.Map;

/**
 * A concrete class called Car with unique characteristics. 
 * 
 * @author Matthew Kim
 * @version Winter 2022
 *
 */
public class Car extends AbstractVehicle {
    /**
     * Object will be dead for 15 frames.
     */
    private static final int DEATH_TIME = 15;
    
    /**
     * Creates the Car object.
     * @param theX the X position of the vehicle.
     * @param theY the Y position of the vehicle.
     * @param theDir the direction the vehicle is facing.
     */    
    public Car(final int theX, final int theY, final Direction theDir) {
        super(theX, theY, theDir, DEATH_TIME);
    }
    
    /**
     * Checks light color.
     * Moves on yellow if the terrain is not a crosswalk.
     * Moves on all other avaliable scenarios. 
     */
    @Override
    public boolean canPass(final Terrain theTerrain, final Light theLight) {
        switch (theLight) {
            case RED:
                return !(theTerrain == Terrain.LIGHT || theTerrain == Terrain.CROSSWALK);
            case YELLOW:
                return theTerrain != Terrain.CROSSWALK;
            default:
                return true;
        }
    }

    /**
     * Choose direction by checking the avaliable list of directions,
     * the neighboring terrain, and the avaliable list of terrains.
     */
    @Override
    public Direction chooseDirection(final Map<Direction, Terrain> theNeighbors) {
        return checkDirection(getListOfDirections(), theNeighbors, getListOfTerrains('C'));
    }
}