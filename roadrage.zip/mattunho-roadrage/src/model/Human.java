/*
 * TCSS 305 - Road Rage
 */
package model;
import java.util.Map;

/**
 * A class object called Human with unique characteristics. 
 * 
 * @author Matthew Kim
 * @version Winter 2022
 *
 */
public class Human extends AbstractVehicle {

    /**
     * Object will be dead for 45 frames.
     */
    private static final int DEATH_TIME = 45;
    
    /**
     * Creates the Human object.
     * @param theX the X position of the vehicle.
     * @param theY the Y position of the vehicle.
     * @param theDir the direction the vehicle is facing.
     */   
    public Human(final int theX, final int theY, final Direction theDir) {
        super(theX, theY, theDir, DEATH_TIME);
    }
    
    /**
     * Passes if the object is on grass or 
     * if the object is on a non green crosswalk.
     */
    @Override
    public boolean canPass(final Terrain theTerrain, final Light theLight) {
        return theTerrain == Terrain.GRASS 
                        || theTerrain == Terrain.CROSSWALK && theLight != Light.GREEN;
    }
    
    /**
     * Choose direction by taking the preffered direction 
     * and preffered terrain into account.
     */
    @Override
    public Direction chooseDirection(final Map<Direction, Terrain> theNeighbors) {
        return getPrefferedDirection(theNeighbors, Terrain.CROSSWALK, 
                                     getListOfTerrains('H'), true);
    }
}