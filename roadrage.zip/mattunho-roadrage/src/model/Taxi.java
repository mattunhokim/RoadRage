/*
 * TCSS 305 - Road Rage
 */
package model;
import java.util.Map;

/**
 * A class object called Taxi with unique characteristics. 
 * 
 * @author Matthew Kim
 * @version Winter 2022
 *
 */
public class Taxi extends AbstractVehicle {
    /**
     * Object will be dead for 15 frames.
     */
    private static final int DEATH_TIME = 15;  
    
    /**
     * Wait time for red crosswalks.
     */
    private static final int CLOCK_CYCLE = 3;
    
    /**
     * Objects wait time for red crosswalks.
     */
    private int myCrosswalkCounter;
    
    /**
     * Creates the Taxi object.
     * @param theX the X position of the vehicle.
     * @param theY the Y position of the vehicle.
     * @param theDir the direction the vehicle is facing.
     */    
    public Taxi(final int theX, final int theY, final Direction theDir) {
        super(theX, theY, theDir, DEATH_TIME);
    }
    
    /**
     * Checks to see if light is red and a crosswalk.
     * Waits 3 clock cycles and crosses.
     * Does not pass on red and terrain light.
     * Otherwise passes all other avaliable terrain.
     */
    @Override
    public boolean canPass(final Terrain theTerrain, final Light theLight) {
        if (theLight == Light.RED) {
            if (theTerrain == Terrain.CROSSWALK) {
                return myCrosswalkCounter++ >= CLOCK_CYCLE;
            }
            return theTerrain != Terrain.LIGHT;
        }
        myCrosswalkCounter = 0;
        return true;
    }

    /**
     * Choose direction by checking the avaliable list of directions,
     * the neighboring terrain, and the avaliable list of terrains.
     */
    @Override
    public Direction chooseDirection(final Map<Direction, Terrain> theNeighbors) {
        return checkDirection(getListOfDirections(), theNeighbors, getListOfTerrains('X'));
    }
}