/*
 * TCSS 305 - Road Rage
 */
package model;
import java.util.Map;

/**
 * A concrete class called Truck with unique characteristics. 
 * 
 * @author Matthew Kim
 * @version Winter 2022
 *
 */
public class Truck extends AbstractVehicle {
    
    /**
     * Object will never be dead.
     */
    private static final int DEATH_TIME = 0;   
    
    /**
     * Creates the Truck object.
     * @param theX the X position of the vehicle.
     * @param theY the Y position of the vehicle.
     * @param theDir the direction the vehicle is facing.
     */    
    public Truck(final int theX, final int theY, final Direction theDir) {
        super(theX, theY, theDir, DEATH_TIME);
    }
    
    @Override
    public boolean canPass(final Terrain theTerrain, final Light theLight) {
        return theTerrain == Terrain.STREET || theTerrain == Terrain.LIGHT 
                        || theTerrain == Terrain.CROSSWALK && theLight != Light.RED;
    }
    
    /**
     * Choose direction by checking the avaliable list of randomized directions,
     * the neighboring terrain, and the avaliable list of terrains.
     */
    @Override
    public Direction chooseDirection(final Map<Direction, Terrain> theNeighbors) {
        return checkDirection(getListOfDirections(true), theNeighbors, getListOfTerrains('T'));
    }
}