/*
 * TCSS 305 - Road Rage
 */
package model;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * An abstract class defining behaviors for all child classes. 
 * 
 * @author Matthew Kim
 * @version Winter 2022
 *
 */
public abstract class AbstractVehicle implements Vehicle {
    
    /**
     * Current X position of object.
     */
    private int myX;
    
    /**
     * Current Y position of object.
     */
    private int myY;
    
    /**
     * Starting X position.
     */
    private final int myStartingX;
    
    /**
     * Starting Y position.
     */
    private final int myStartingY;
    
    /**
     * Time the object stays dead.
     */
    private final int myDeathTime;
    
    /**
     * Time till object revives.
     */
    private int myReviveTime;
    
    /**
     * Current direction of object.
     */
    private Direction myDirection;
    
    /**
     * Starting direction of object.
     */
    private final Direction myStartingDirection;
    
    /**
     * Whether or not the vehicle is dead.
     */
    private boolean myVehicleDied;  
    
    /**
     * Creates an abstract object that all child classes have similar behaviors of. 
     * @param theX the X position of the object.
     * @param theY the Y position of the object.
     * @param theDir the direction of the object.
     * @param theDeathTime the deathtime of the object. 
     */
    public AbstractVehicle(final int theX, final int theY, 
                           final Direction theDir, final int theDeathTime) {
        myX = theX;
        myY = theY;
        myStartingX = theX;
        myStartingY = theY;
        myDeathTime = theDeathTime;
        myReviveTime = theDeathTime;
        myDirection = theDir;
        myStartingDirection = theDir;
    }
    
    @Override
    public void collide(final Vehicle theOther) {
        myVehicleDied = this.myDeathTime > theOther.getDeathTime();
    }
    
    @Override
    public int getDeathTime() {
        return myDeathTime;
    }
    
    @Override
    public String getImageFileName() {        
        String image = getClass().getSimpleName().toLowerCase(Locale.US);
        if (!this.isAlive()) {
            image += "_dead";
        }
        return image + ".gif";
    }
    
    @Override
    public Direction getDirection() {
        return myDirection;
    }
    
    @Override
    public int getX() {
        return myX;
    }
    
    @Override
    public int getY() {
        return myY;
    }
    
    @Override
    public boolean isAlive() {    
        return !myVehicleDied;
    }
    
    @Override
    public void poke() {
        if (myVehicleDied) {
            myReviveTime = Math.max(myReviveTime - 1, 0);

            if (myReviveTime == 0) {
                setDirection(Direction.random());
                myVehicleDied = false;
                myReviveTime = myDeathTime;
            }   
        }
    }
    
    @Override
    public void reset() {
        myX = myStartingX;
        myY = myStartingY;
        myDirection = myStartingDirection;
        myReviveTime = 0;
    }
    
    @Override
    public void setDirection(final Direction theDir) {
        myDirection = theDir;
    }
    
    @Override
    public void setX(final int theX) {
        myX = theX;
    }
    
    @Override
    public void setY(final int theY) {
        myY = theY;
    }
    
    /**
     * Adds acceptable directions to a list.
     * @param theShuffle randomize directions.
     * @return Creates a list of randomized acceptable directions.
     */
    protected List<Direction> getListOfDirections(final boolean theShuffle) {
        final List<Direction> diffDirection = new ArrayList<Direction>();
        
        diffDirection.add(getDirection());
        diffDirection.add(getDirection().left());
        diffDirection.add(getDirection().right());
        
        if (theShuffle) {
            Collections.shuffle(diffDirection);
        }
        return diffDirection;
    }
    
    /**
     * Overloaded method of getListofDirections, does not shuffle.
     * @return a list of directions in the order of straight, left, right.
     */
    protected List<Direction> getListOfDirections() {
        return getListOfDirections(false);
    }
    
    /**
     * Adds acceptable terrain based on vehicle type.
     * @param theVehicleType denotes which child class vehicle is chosen.
     * @return Creates a list of acceptable terrains based on vehicle type.
     */
    protected List<Terrain> getListOfTerrains(final char theVehicleType) {
        final List<Terrain> listOfTerrains = new ArrayList<Terrain>();
        
        switch (theVehicleType) {
            case 'B': //Bicycle
                listOfTerrains.add(Terrain.TRAIL);
                listOfTerrains.add(Terrain.STREET);
                listOfTerrains.add(Terrain.LIGHT);
                listOfTerrains.add(Terrain.CROSSWALK);
                break;
            case 'A': //ATV
                listOfTerrains.add(Terrain.GRASS);
                listOfTerrains.add(Terrain.STREET);
                listOfTerrains.add(Terrain.LIGHT);
                listOfTerrains.add(Terrain.TRAIL);
                listOfTerrains.add(Terrain.CROSSWALK);
                break;
            case 'H': //Human
                listOfTerrains.add(Terrain.GRASS);
                listOfTerrains.add(Terrain.CROSSWALK);
                break;
            default: //All other vehicles.
                listOfTerrains.add(Terrain.STREET);
                listOfTerrains.add(Terrain.LIGHT);
                listOfTerrains.add(Terrain.CROSSWALK);
                break;
        }
        return listOfTerrains;
    }
    
    /**
     * Checks which direction is legal for the subclass Vehicles to take based off the terrian.
     * @param theDiffDirection The choices of directions.
     * @param theNeighbors The list of neighbor terrain types.
     * @param theListOfTerrains The acceptable terrians.
     * @return If any of the choices are legal then return legal choice,
     *     otherwise go back for a different choice.
     */
    protected Direction checkDirection(final List<Direction> theDiffDirection,
                                          final Map<Direction, Terrain> theNeighbors, 
                                          final List<Terrain> theListOfTerrains) {

        for (final Direction directionChoice : theDiffDirection) {            
            if (theListOfTerrains.contains(theNeighbors.get(directionChoice))) {
                return directionChoice;
            }
        } 
        return getDirection().reverse();
    }
    
    /**
     * Checks if a preferred terrain is in one of the available directions.
     * @param theNeighbors The list of neighbor terrain types.
     * @param thePreferredTerrain The terrain type being sought.
     * @param theTerrainList The acceptable terrain for specific vehicle.
     * @param theShuffle Does the vehicle choose random direction.
     * @return A direction of the preferred terrain type.
     */
    protected Direction getPrefferedDirection(final Map<Direction, Terrain> theNeighbors, 
                                              final Terrain thePreferredTerrain, 
                                              final List<Terrain> theTerrainList, 
                                              final boolean theShuffle) {
        
        Direction defaultDirection = checkDirection(getListOfDirections(theShuffle), 
                                                    theNeighbors, theTerrainList);
        
        if (theNeighbors.get(getDirection()) == thePreferredTerrain) {
            defaultDirection = getDirection();
        }
        if (theNeighbors.get(getDirection().left()) == thePreferredTerrain) {
            defaultDirection = getDirection().left();
        }
        if (theNeighbors.get(getDirection().right()) == thePreferredTerrain) {
            defaultDirection = getDirection().right();
        }
        return defaultDirection;
    }
}