/*
 * TCSS 305 - Road Rage
 */
package model;
import java.util.Map;

/**
 * A concrete class called Bicycle with unique characteristics. 
 * 
 * @author Matthew Kim
 * @version Winter 2022
 *
 */
public class Bicycle extends AbstractVehicle implements Vehicle {
    
    /**
     * Object will be dead for 35 frames.
     */
    private static final int DEATH_TIME = 35;
    
    /**
     * Creates the Bicycle object.
     * @param theX the X position of the vehicle.
     * @param theY the Y position of the vehicle.
     * @param theDir the direction the vehicle is facing.
     */
    public Bicycle(final int theX, final int theY, final Direction theDir) {
        super(theX, theY, theDir, DEATH_TIME);
    }
    
    /**
     * Passes if the light is green or
     * if the object is not in front of the terrain light or crosswalk.
     */
    @Override
    public boolean canPass(final Terrain theTerrain, final Light theLight) {
        if (theLight == Light.GREEN) {
            return true;
        } else {
            return !(theTerrain == Terrain.LIGHT || theTerrain == Terrain.CROSSWALK);
        }
    }
    
    /**
     * Choose direction by taking the preffered direction 
     * and preffered terrain into account.
     */
    @Override
    public Direction chooseDirection(final Map<Direction, Terrain> theNeighbors) {
        return getPrefferedDirection(theNeighbors, Terrain.TRAIL, 
                                     getListOfTerrains('B'), false);
    }
}